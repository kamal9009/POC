$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/Ashok/CucumberFramework/CucumberSeleniumPOC/src/main/java/features/Login.feature");
formatter.feature({
  "line": 2,
  "name": "Sample FaceBook Test Scripts",
  "description": "",
  "id": "sample-facebook-test-scripts",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@smoke"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Login to FaceBook App",
  "description": "",
  "id": "sample-facebook-test-scripts;login-to-facebook-app",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User on FaceBook Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enter valid credentials and clicked on submit",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "User navigated to the Home page",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});