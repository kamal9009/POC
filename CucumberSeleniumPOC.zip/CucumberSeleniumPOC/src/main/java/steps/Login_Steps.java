package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.LoginPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class  Login_Steps{
	
	private WebDriver driver;
	@Given("^User on FaceBook Login Page$")
	public void user_on_FaceBook_Login_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Ashok\\CucumberFramework\\CucumberSeleniumPOC\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		new LoginPage(driver);
		driver.get("https://www.facebook.com");
	}

	@Given("^User enter valid credentials and clicked on submit$")
	public void user_enter_valid_credentials_and_clicked_on_submit() throws Throwable {
		//homepage = loginpage.User_Login();
	}

	@Then("^User navigated to the Home page$")
	public void user_navigated_to_the_Home_page() throws Throwable {
		//homepage.verigyLogoutMenu();
	}
}
