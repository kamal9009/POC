package Pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage{

	WebDriver driver;
	
	/**
	 * Constructor to assign driver to current, super classes and initialize page factory elements
	 * @param driver
	 */
	public LoginPage(WebDriver driver) {
		//super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="email")
	WebElement username;
	
	@FindBy(id="pass")
	WebElement password;
	
	@FindBy(id="u_0_4")
	WebElement login;
	
	/**
	 * Navigate to FaceBook URL
	 */
	public void GotoURL() {
		driver.get("https://www.facebook.com/");
	}
	
	/**
	 * Method to Enter User Credentials
	 * @return 
	 */
	public HomePage User_Login() {
		username.sendKeys("Zenqa1user@gmail.com");
		password.sendKeys("second@123");
		login.click();
		return new HomePage(driver);
	}
	
	/**
	 * verify login page
	 */
	public void verifyLoginPage(){
		Assert.assertTrue(username.isDisplayed());
	}
}
