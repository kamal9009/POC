package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "C:\\Users\\Ashok\\CucumberFramework\\CucumberSeleniumPOC\\src\\main\\java\\features\\Login.feature", //the path of the feature files
		glue={"C:\\Users\\Ashok\\CucumberFramework\\CucumberSeleniumPOC\\src\\main\\java\\steps"}, //the path of the step definition files		
		format = {"pretty","html:test-output"}
		)


public class TestRunner {

}
