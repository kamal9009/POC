$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login.feature");
formatter.feature({
  "line": 1,
  "name": "WorkForce Tracking Loing Test",
  "description": "",
  "id": "workforce-tracking-loing-test",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Successfull Login Test",
  "description": "",
  "id": "workforce-tracking-loing-test;successfull-login-test",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "I am on the Workforce Tracking login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "I enter the valid credentials",
  "keyword": "And "
});
formatter.step({
  "line": 6,
  "name": "I enter the login button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "I am navigated to overview page",
  "keyword": "Then "
});
formatter.match({
  "location": "Login_Stepdef.i_am_on_the_Workforce_Tracking_login_page()"
});
formatter.result({
  "duration": 213503800,
  "status": "passed"
});
formatter.match({
  "location": "Login_Stepdef.i_enter_the_valid_credentials()"
});
formatter.result({
  "duration": 166900,
  "status": "passed"
});
formatter.match({
  "location": "Login_Stepdef.i_enter_the_login_button()"
});
formatter.result({
  "duration": 165300,
  "status": "passed"
});
formatter.match({
  "location": "Login_Stepdef.i_am_navigated_to_overview_page()"
});
formatter.result({
  "duration": 22900,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 9,
  "name": "Invalid Login Test",
  "description": "",
  "id": "workforce-tracking-loing-test;invalid-login-test",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "I am on the Workforce Tracking login page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "I enter credentials as \u003cSample\u003e, \u003cSample1\u003e,\u003cdfsdf\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I enter the login button",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "I am shown as valid error messsage \u0027Authentication error\u0027",
  "keyword": "Then "
});
formatter.examples({
  "line": 15,
  "name": "",
  "description": "",
  "id": "workforce-tracking-loing-test;invalid-login-test;",
  "rows": [
    {
      "cells": [
        "Sample",
        "Sample1",
        "dfsdf"
      ],
      "line": 16,
      "id": "workforce-tracking-loing-test;invalid-login-test;;1"
    },
    {
      "cells": [
        "name1",
        "5",
        "success"
      ],
      "line": 17,
      "id": "workforce-tracking-loing-test;invalid-login-test;;2"
    },
    {
      "cells": [
        "name2",
        "7",
        "Fail"
      ],
      "line": 18,
      "id": "workforce-tracking-loing-test;invalid-login-test;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 17,
  "name": "Invalid Login Test",
  "description": "",
  "id": "workforce-tracking-loing-test;invalid-login-test;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "I am on the Workforce Tracking login page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "I enter credentials as name1, 5,success",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I enter the login button",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "I am shown as valid error messsage \u0027Authentication error\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Login_Stepdef.i_am_on_the_Workforce_Tracking_login_page()"
});
formatter.result({
  "duration": 267000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 27
    },
    {
      "val": "5",
      "offset": 30
    }
  ],
  "location": "Login_Stepdef.i_enter_credentials_as_name_success(int,int)"
});
formatter.result({
  "duration": 2221200,
  "status": "passed"
});
formatter.match({
  "location": "Login_Stepdef.i_enter_the_login_button()"
});
formatter.result({
  "duration": 237900,
  "status": "passed"
});
formatter.match({
  "location": "Login_Stepdef.i_am_shown_as_valid_error_messsage_Authentication_error()"
});
formatter.result({
  "duration": 35301,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Invalid Login Test",
  "description": "",
  "id": "workforce-tracking-loing-test;invalid-login-test;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "I am on the Workforce Tracking login page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "I enter credentials as name2, 7,Fail",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "I enter the login button",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "I am shown as valid error messsage \u0027Authentication error\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Login_Stepdef.i_am_on_the_Workforce_Tracking_login_page()"
});
formatter.result({
  "duration": 405900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 27
    },
    {
      "val": "7",
      "offset": 30
    }
  ],
  "location": "Login_Stepdef.i_enter_credentials_as_name_Fail(int,int)"
});
formatter.result({
  "duration": 87900,
  "status": "passed"
});
formatter.match({
  "location": "Login_Stepdef.i_enter_the_login_button()"
});
formatter.result({
  "duration": 53900,
  "status": "passed"
});
formatter.match({
  "location": "Login_Stepdef.i_am_shown_as_valid_error_messsage_Authentication_error()"
});
formatter.result({
  "duration": 67900,
  "status": "passed"
});
});