package Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class FileUtilities {
	public static Properties properties= new Properties();
	
	/**
	 * Returns value for required key from Environment.propeties file 
	 * @param sKey
	 * @return Propety key's value
	 */
	public static String getConfigProperty(String sKey){
		String sKeyValue=null;
		   try {
			FileInputStream inputStream = new FileInputStream(new File(System.getProperty("user.dir")+File.separator+"src"+File.separator+"ConfigFiles"+File.separator+"Environment.properties"));
		    properties.load(inputStream);
		     sKeyValue = properties.getProperty(sKey);
		   } catch (Exception e) {
			e.printStackTrace();
		}
		return sKeyValue;
	}
}
