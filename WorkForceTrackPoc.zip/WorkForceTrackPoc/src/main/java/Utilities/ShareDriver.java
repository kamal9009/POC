package Utilities;

import org.openqa.selenium.WebDriver;

import Base.BrowserSetup;

/**
 * Main class where the web driver object is shared to cucumber step definition classes.
 *
 */
public class ShareDriver {
	
static BrowserSetup browserSetup;
public static WebDriver driver;

// close thread
private static final Thread CLOSE_THREAD = new Thread() {
	
	/**
	 * Over ridden run method of close thread, executes once after the test execution and quits the web driver.
	 */
	@Override
	public void run() {
		try{
		driver.quit();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
};

  /**
    *Block that executes once in the beginning of test execution,shares driver to step definitions and adds shut down hook.
    *
    */
	static{
		browserSetup = new BrowserSetup();
		driver = browserSetup.getDriver();
		Runtime.getRuntime().addShutdownHook(CLOSE_THREAD);
	}
	
	/**
	 * Throws Unsupported operation if the current thread is not equal to close thread.
	 */
	public void close() {
		if (Thread.currentThread() != CLOSE_THREAD) {
			throw new UnsupportedOperationException(
					"You shouldn't close this WebDriver. It's shared and will close when the JVM exits.");
		}
	}
}