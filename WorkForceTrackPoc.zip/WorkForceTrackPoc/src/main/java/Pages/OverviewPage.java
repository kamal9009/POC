package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import junit.framework.Assert;

public class OverviewPage {
	WebDriver driver;

	/**
	 * Constructor to assign driver to current, super classes and initialize page factory elements
	 * @param driver
	 */
	public OverviewPage(WebDriver driver) {
		//super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "logoutMenu")
	WebElement logoutmenu;

	@FindBy(id = "findFriendsNav")
	WebElement findfriends;

	@FindBy(xpath = "//div[@id='u_fetchstream_3_1']//a[@text()='View Sent Requests']")
	WebElement viewfrndreq;

	@FindBy(xpath = "//div[@id='js_i5']//li[9]/a")
	WebElement logoutOpt;

	/**
	 * verify the logout menu
	 */
	public void verifyLogoutMenu() {
		Assert.assertTrue(logoutmenu.isDisplayed());
	}

	/**
	 * Navigate to 'FindFriends' page
	 */
	public void goToFindFriends() {
		findfriends.click();
	}

	/**
	 * verify view friend request
	 */
	public void verifyFrndReqPage() {
		Assert.assertTrue(viewfrndreq.isDisplayed());
	}

	/**
	 * Logout of the app
	 * 
	 * @return
	 */
	public LoginPage logout() {
		logoutmenu.click();
		logoutOpt.click();
		return new LoginPage(driver);
	}
}
