package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utilities.FileUtilities;
import junit.framework.Assert;

public class LoginPage {
	WebDriver driver;

	/**
	 * Constructor to assign driver to current, super classes and initialize
	 * page factory elements
	 * 
	 * @param driver
	 */
	public LoginPage(WebDriver driver) {
		// super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "email")
	WebElement username;

	@FindBy(id = "pass")
	WebElement password;

	@FindBy(id = "u_0_4")
	WebElement login;

	/**
	 * Navigate to FaceBook URL
	 */
	public void GotoURL() {
		String url = FileUtilities.getConfigProperty("URL");
		System.out.println("++++++++++++++ URL: "+url);
		driver.get(url);
	}

	/**
	 * Method to Enter User Credentials
	 * 
	 * @return
	 */
	public void User_Login(String uname, String pwd) {
		username.sendKeys(uname);
		password.sendKeys(pwd);

	}

	/***
	 * Method to click login button
	 */
	public OverviewPage clickLogin() {
		login.click();
		return new OverviewPage(driver);
	}

	/**
	 * verify login page
	 */
	public void verifyLoginPage() {
		Assert.assertTrue(username.isDisplayed());
	}
}
