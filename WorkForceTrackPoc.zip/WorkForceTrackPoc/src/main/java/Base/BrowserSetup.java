package Base;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Utilities.FileUtilities;

public class BrowserSetup {
    
	private WebDriver driver;
	static String driverPath = System.getProperty("user.dir")+File.separator+"Resources"+File.separator;
    
	/**
	 * Returns Web Driver object
	 * @return driver
	 */
	public WebDriver getDriver() {
		System.out.println("+++++++++++ ENtered driver : ");
		setDriver();
		return driver;
	}
    
	/**
	 * Initializes web driver object for specified browser name in Environment.properties
	 */
	public void setDriver() {
		System.out.println("=========== BROWSER ============"+FileUtilities.getConfigProperty("Browser").toLowerCase());
		switch (FileUtilities.getConfigProperty("Browser").toLowerCase()) {
		case "chrome":
			System.out.println("******** Staring Chrome setup ");
			driver = initChromeDriver();
			System.out.println("******** Chrome setup done");
			break;

		default:
			System.out.println("browser : " + FileUtilities.getConfigProperty("Browser")
					+ " is invalid, Launching Firefox as browser of choice..");
		}
	}
   
	/**
	 * Initializes Chrome Browser
	 * @return chrome driver;
	 */
	private static WebDriver initChromeDriver() {
		System.out.println("Launching google chrome with new profile..");
		System.setProperty("webdriver.chrome.driver", driverPath
				+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		return driver;
	}
}
