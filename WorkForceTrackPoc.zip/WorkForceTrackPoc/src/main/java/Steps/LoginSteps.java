package Steps;

import org.openqa.selenium.WebDriver;

import Pages.LoginPage;
import Pages.OverviewPage;
import Utilities.FileUtilities;
import Utilities.ShareDriver;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	
	// Page Object References
	private OverviewPage overviewPage;
	private LoginPage loginPage;
    private WebDriver driver;
    
    
    /**
     * Cucumber before method, runs before every Scenario
     */
	@Before
	public void SetUp(){
		driver= ShareDriver.driver;
		loginPage = new LoginPage(driver);
	}
	
	@Given("^I am on the Workforce Tracking login page$")
	public void i_am_on_the_Workforce_Tracking_login_page() throws Throwable {
		loginPage.GotoURL();
	}

	@Given("^I enter the valid credentials$")
	public void i_enter_the_valid_credentials() throws Throwable {
		String user = FileUtilities.getConfigProperty("UserName");
		String pwd = FileUtilities.getConfigProperty("Password");
		loginPage.User_Login(user,pwd);
	}

	@When("^I enter the login button$")
	public void i_enter_the_login_button() throws Throwable {
		overviewPage = loginPage.clickLogin();
	}

	@Then("^I am navigated to overview page$")
	public void i_am_navigated_to_overview_page() throws Throwable {
		overviewPage.verifyLogoutMenu();
	}

	@Given("^I enter credentials as name(\\d+), (\\d+),success$")
	public void i_enter_credentials_as_name_success(int arg1, int arg2) throws Throwable {

	}

	@Then("^I am shown as valid error messsage 'Authentication error'$")
	public void i_am_shown_as_valid_error_messsage_Authentication_error() throws Throwable {

	}

	@Given("^I enter credentials as name(\\d+), (\\d+),Fail$")
	public void i_enter_credentials_as_name_Fail(int arg1, int arg2) throws Throwable {
		
	}
}
