package Steps;


import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Utilities.ShareDriver;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;


public class Hooks {
	
	/**
	 * Cucumber before method that runs before every scenario
	 */
	
	@Before
	public void runFirst(){

	}
	
	/**
	 * Cucumber after method that runs after every scenario, stops video recording, takes screen shot and embeds the same to 
	 * test reports if there is a test failure.
	 * @param scenario
	 */
	@After
	public void runLast(Scenario scenario){
		if(scenario.isFailed()){
		  final byte[] screenshot = ((TakesScreenshot) ShareDriver.driver).getScreenshotAs(OutputType.BYTES);
	      scenario.embed(screenshot, "image/png");
		}
	}
	
	
	
}