package Runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/java/Features",
		//tags= "@DummyOne,@DummyTwo,@DummyThree,@DummyFour,@DummyFive,@AnswerQuestion,@UserProfile",
		//tags = "@AnswerQuestion,@UserProfile",
		plugin={"pretty","html:TestReports/LatestResults/SimpleHtml"},
		glue = "Steps",
		monochrome = true
		)
public class RunCucumberTests {

}
